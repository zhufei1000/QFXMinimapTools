local ADDON_NAME, QMT = ...
QMT = QMT or {}
_G.QFXMinimapTools = QMT

local L = setmetatable({}, { __index = function(_, key) return QMT.L and QMT.L[key] end })
local SafeCall = QMT.SafeCall
local Clamp = QMT.Clamp
local Round = QMT.Round
local AccentHex = QMT.AccentHex
local DisplayAccentHex = QMT.DisplayAccentHex
local ColorText = QMT.ColorText
local IsDescendant = QMT.IsDescendant
local Print = QMT.Print
local NormalizeLanguageChoice = QMT.NormalizeLanguageChoice
local SelectLocale = QMT.SelectLocale

-- Options UI
-- ############################################################
-- Unified native-style layout for the standalone settings dialog.
-- The helpers below keep labels, controls, sliders, and buttons aligned
-- across English and Chinese without adding a second UI framework.
local BACKDROP_TEMPLATE = BackdropTemplateMixin and "BackdropTemplate" or nil
local OPTION_LAYOUT = {
    panelW = 720,
    panelH = 780,
    margin = 24,
    sectionGap = 12,
    labelW = 118,
    controlGap = 8,
    controlW = 170,
    sliderW = 170,
    valueW = 46,
    rowH = 26,
    sliderRowH = 42,
    checkTextW = 290,
}

local function RefreshStatsFromOptions()
    if QMT.RefreshStatUpdaterState then QMT:RefreshStatUpdaterState() end
    if QMT.RefreshPhaseEventRegistration then QMT:RefreshPhaseEventRegistration() end
    if QMT.PlaceAllStatFrames then QMT:PlaceAllStatFrames() end
    if QMT.UpdateAllStats then QMT:UpdateAllStats() end
end

local function FormatSliderLimit(value)
    if type(value) ~= "number" then return tostring(value or "") end
    if value == math.floor(value) then return tostring(value) end
    return string.format("%.2f", value)
end

local function MakeHeader(parent, text, x, y, width)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    fs:SetPoint("TOPLEFT", x, y)
    fs:SetWidth(width or 260)
    fs:SetJustifyH("LEFT")
    fs:SetText(text)
    fs:SetTextColor(1, 0.82, 0)
    return fs
end

local function MakeSection(parent, text, x, y, width, height)
    local section = CreateFrame("Frame", nil, parent, BACKDROP_TEMPLATE)
    section:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    section:SetSize(width, height)
    if section.SetBackdrop then
        section:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true,
            tileSize = 16,
            edgeSize = 12,
            insets = { left = 3, right = 3, top = 3, bottom = 3 },
        })
        if section.SetBackdropColor then section:SetBackdropColor(0.05, 0.05, 0.05, 0.55) end
        if section.SetBackdropBorderColor then section:SetBackdropBorderColor(0.55, 0.45, 0.22, 0.85) end
    end
    section.qfxTitle = MakeHeader(section, text, 12, -10, width - 24)
    return section
end

local function MakeRowLabel(parent, text, x, y, width)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetPoint("TOPLEFT", x, y - 3)
    fs:SetSize(width or OPTION_LAYOUT.labelW, OPTION_LAYOUT.rowH)
    fs:SetJustifyH("LEFT")
    fs:SetJustifyV("MIDDLE")
    fs:SetWordWrap(true)
    fs:SetText(text)
    return fs
end

local function GetControlX(x, labelW)
    return x + (labelW or OPTION_LAYOUT.labelW) + OPTION_LAYOUT.controlGap
end

local function SetFontStringEnabled(fontString, enabled, r, g, b)
    if not fontString or not fontString.SetTextColor then return end
    if enabled then
        fontString:SetTextColor(r or 1, g or 1, b or 1)
    else
        fontString:SetTextColor(0.55, 0.55, 0.55)
    end
end

local function SetControlEnabled(control, enabled)
    if not control then return end
    enabled = enabled and true or false
    if control.Enable and control.Disable then
        if enabled then control:Enable() else control:Disable() end
    elseif control.EnableMouse then
        control:EnableMouse(enabled)
    end
    if control.SetAlpha then control:SetAlpha(enabled and 1 or 0.55) end
    SetFontStringEnabled(control.qfxLabel, enabled, 1, 0.82, 0)
    SetFontStringEnabled(control.Text, enabled)
    SetFontStringEnabled(control.Value, enabled)
    SetFontStringEnabled(control.Low, enabled, 0.75, 0.75, 0.75)
    SetFontStringEnabled(control.High, enabled, 0.75, 0.75, 0.75)

    if control.GetName then
        local name = control:GetName()
        local ddButton = name and _G[name .. "Button"]
        if ddButton and ddButton.Enable and ddButton.Disable then
            if enabled then ddButton:Enable() else ddButton:Disable() end
        end
    end

    if control.SetEnabled then
        control:SetEnabled(enabled)
    end
    if control.SetTextColor and control.GetObjectType and control:GetObjectType() == "EditBox" then
        if enabled then control:SetTextColor(1, 1, 1, 1) else control:SetTextColor(0.55, 0.55, 0.55, 1) end
    end
end

local function CommitOptions(applyFunc)
    if applyFunc then
        applyFunc()
    else
        QMT:ApplyAll()
    end
    if QMT.RefreshOptionsControlState then QMT:RefreshOptionsControlState() end
end

local function MakeCheck(parent, text, x, y, getValue, setValue, width, applyFunc)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", x, y)
    cb:SetSize(24, 24)
    if cb.Text and cb.Text.ClearAllPoints then cb.Text:ClearAllPoints() end
    if cb.Text then
        cb.Text:SetPoint("LEFT", cb, "RIGHT", 2, 0)
        cb.Text:SetWidth(width or OPTION_LAYOUT.checkTextW)
        cb.Text:SetJustifyH("LEFT")
        cb.Text:SetText(text)
    end
    cb:SetChecked(getValue())
    cb:SetScript("OnClick", function(self)
        setValue(self:GetChecked() and true or false)
        CommitOptions(applyFunc)
    end)
    return cb
end

local sliderIndex = 0
local function MakeSlider(parent, label, x, y, labelW, sliderW, minV, maxV, step, getValue, setValue, formatText, applyFunc)
    sliderIndex = sliderIndex + 1
    labelW = labelW or OPTION_LAYOUT.labelW
    sliderW = sliderW or OPTION_LAYOUT.sliderW
    local rowLabel = MakeRowLabel(parent, label, x, y, labelW)
    rowLabel:SetTextColor(1, 0.82, 0)
    local controlX = GetControlX(x, labelW)
    local name = "QFXMinimapToolsSlider" .. sliderIndex
    local s = CreateFrame("Slider", name, parent, "OptionsSliderTemplate")
    s:SetPoint("TOPLEFT", parent, "TOPLEFT", controlX, y - 2)
    s:SetWidth(sliderW)
    s:SetMinMaxValues(minV, maxV)
    s:SetValueStep(step)
    if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
    if _G[name .. "Text"] then _G[name .. "Text"]:SetText("") end
    s.Low = _G[name .. "Low"]
    s.High = _G[name .. "High"]
    if s.Low then
        s.Low:ClearAllPoints()
        s.Low:SetPoint("TOPLEFT", s, "BOTTOMLEFT", -1, -3)
        s.Low:SetText(FormatSliderLimit(minV))
    end
    if s.High then
        s.High:ClearAllPoints()
        s.High:SetPoint("TOPRIGHT", s, "BOTTOMRIGHT", 1, -3)
        s.High:SetText(FormatSliderLimit(maxV))
    end
    s.Value = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    s.Value:SetPoint("TOP", s, "BOTTOM", 0, -3)
    s.Value:SetWidth(OPTION_LAYOUT.valueW)
    s.Value:SetJustifyH("CENTER")
    s.qfxLabel = rowLabel
    local function UpdateValue(value)
        s.Value:SetText(formatText and formatText(value) or tostring(value))
    end
    s:SetValue(getValue())
    UpdateValue(s:GetValue())

    local pendingCommit = false
    local function CommitIfNeeded(force)
        if force or not (IsMouseButtonDown and IsMouseButtonDown("LeftButton")) then
            pendingCommit = false
            CommitOptions(applyFunc)
        else
            pendingCommit = true
        end
    end

    s:SetScript("OnValueChanged", function(self, value)
        value = Round(value, step)
        setValue(value)
        UpdateValue(value)
        CommitIfNeeded(false)
    end)
    s:SetScript("OnMouseUp", function()
        if pendingCommit then CommitIfNeeded(true) end
    end)
    return s
end

local function MakeButton(parent, text, x, y, w, h, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT", x, y)
    b:SetSize(w, h)
    b:SetText(text)
    b:SetScript("OnClick", onClick)
    return b
end

local dropdownIndex = 0
local function MakeDropdown(parent, labelText, x, y, labelW, w, options, getValue, setValue)
    labelW = labelW or OPTION_LAYOUT.labelW
    w = w or OPTION_LAYOUT.controlW
    local label = MakeRowLabel(parent, labelText, x, y, labelW)
    label:SetTextColor(1, 0.82, 0)
    local controlX = GetControlX(x, labelW)

    -- Prefer Blizzard's native dropdown template so the control has the
    -- expected dropdown arrow and does not look like a plain button.
    if UIDropDownMenu_Initialize and UIDropDownMenu_SetWidth and UIDropDownMenu_SetText and UIDropDownMenu_CreateInfo and UIDropDownMenu_AddButton then
        dropdownIndex = dropdownIndex + 1
        local name = "QFXMinimapToolsDropdown" .. dropdownIndex
        local dd = CreateFrame("Frame", name, parent, "UIDropDownMenuTemplate")
        -- UIDropDownMenuTemplate has a built-in left padding, so offset it left
        -- slightly to make its visible text/border line up with other controls.
        dd:SetPoint("TOPLEFT", parent, "TOPLEFT", controlX - 18, y + 6)
        UIDropDownMenu_SetWidth(dd, w)
        if UIDropDownMenu_SetButtonWidth then UIDropDownMenu_SetButtonWidth(dd, w) end
        if UIDropDownMenu_JustifyText then UIDropDownMenu_JustifyText(dd, "LEFT") end
        UIDropDownMenu_SetText(dd, getValue())
        UIDropDownMenu_Initialize(dd, function(_, level)
            for _, opt in ipairs(options or {}) do
                if opt and opt.key then
                    local text = opt.label or opt.key
                    local info = UIDropDownMenu_CreateInfo()
                    info.text = text
                    info.checked = tostring(getValue() or "") == tostring(text)
                    info.func = function()
                        setValue(opt.key)
                        if UIDropDownMenu_SetText then
                            UIDropDownMenu_SetText(dd, getValue() or text)
                        end
                        if CloseDropDownMenus then CloseDropDownMenus() end
                        if QMT.RefreshOptionsControlState then QMT:RefreshOptionsControlState() end
                    end
                    UIDropDownMenu_AddButton(info, level)
                end
            end
        end)
        dd.qfxLabel = label
        dd.SetText = function(self, text)
            UIDropDownMenu_SetText(self, text or "")
        end
        dd.GetText = function(self)
            if UIDropDownMenu_GetText then return UIDropDownMenu_GetText(self) end
            return ""
        end
        return dd, nil, label
    end

    local button = CreateFrame("Button", nil, parent, BACKDROP_TEMPLATE)
    button:SetPoint("TOPLEFT", parent, "TOPLEFT", controlX, y - 1)
    button:SetSize(w, 24)
    button:SetFrameLevel((parent:GetFrameLevel() or 1) + 2)
    if button.SetBackdrop then
        button:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize = 12,
            insets = {left = 3, right = 3, top = 3, bottom = 3},
        })
        button:SetBackdropColor(0.04, 0.04, 0.04, 0.88)
        button:SetBackdropBorderColor(0.45, 0.45, 0.45, 1)
    end

    button.Text = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.Text:SetPoint("LEFT", 8, 0)
    button.Text:SetPoint("RIGHT", -24, 0)
    button.Text:SetJustifyH("LEFT")
    button.qfxLabel = label
    button.SetText = function(self, text)
        self.Text:SetText(text or "")
    end
    button.GetText = function(self)
        return self.Text:GetText()
    end

    button.Arrow = button:CreateTexture(nil, "OVERLAY")
    button.Arrow:SetSize(16, 16)
    button.Arrow:SetPoint("RIGHT", -5, 0)
    button.Arrow:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up")

    button.Highlight = button:CreateTexture(nil, "HIGHLIGHT")
    button.Highlight:SetAllPoints(button)
    button.Highlight:SetColorTexture(1, 1, 1, 0.08)

    local menu = CreateFrame("Frame", nil, button, BACKDROP_TEMPLATE)
    menu:SetFrameStrata("DIALOG")
    menu:SetFrameLevel((button:GetFrameLevel() or 1) + 20)
    menu:SetPoint("TOPLEFT", button, "BOTTOMLEFT", 0, -2)
    menu:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        edgeSize = 16,
        insets = {left = 4, right = 4, top = 4, bottom = 4},
    })
    menu:Hide()
    button.qfxMenu = menu

    local rowH = 22
    local menuW = w
    local count = 0
    for _, opt in ipairs(options or {}) do
        if opt and opt.key then
            count = count + 1
            local row = CreateFrame("Button", nil, menu)
            row:SetPoint("TOPLEFT", 8, -6 - (count - 1) * rowH)
            row:SetSize(menuW - 16, rowH)
            row.Text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.Text:SetPoint("LEFT", 6, 0)
            row.Text:SetText(opt.label or opt.key)
            row.Highlight = row:CreateTexture(nil, "HIGHLIGHT")
            row.Highlight:SetAllPoints(row)
            row.Highlight:SetColorTexture(1, 1, 1, 0.12)
            row:SetScript("OnClick", function()
                setValue(opt.key)
                menu:Hide()
                button:SetText(opt.label or opt.key)
                if QMT.RefreshOptionsControlState then QMT:RefreshOptionsControlState() end
            end)
        end
    end
    menu:SetSize(menuW, math.max(1, count) * rowH + 12)

    button:SetScript("OnClick", function()
        if menu:IsShown() then
            menu:Hide()
        else
            if button.Arrow then button.Arrow:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Down") end
            menu:Show()
        end
    end)
    button:SetScript("OnMouseUp", function()
        if button.Arrow then button.Arrow:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up") end
    end)
    button:SetScript("OnHide", function()
        menu:Hide()
        if button.Arrow then button.Arrow:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up") end
    end)
    menu:SetScript("OnHide", function()
        if button.Arrow then button.Arrow:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up") end
    end)
    button:SetText(getValue())
    return button, menu, label
end

local function SetControlsEnabled(list, enabled)
    if not list then return end
    for _, control in ipairs(list) do
        SetControlEnabled(control, enabled)
    end
end

function QMT:RefreshOptionsControlState()
    local f = self.optionsFrame
    local db = self.db
    if not f or not db then return end
    local minimapEnabled = db.minimap and db.minimap.enabled == true
    local flightEnabled = minimapEnabled and db.minimap and db.minimap.flightCenter == true
    local bagEnabled = db.bag and db.bag.enabled == true
    SetControlsEnabled(f.minimapDependentControls, minimapEnabled)
    SetControlsEnabled(f.flightDependentControls, flightEnabled)
    SetControlsEnabled(f.bagDependentControls, bagEnabled)
end

function QMT:CreateOptionsFrame()
    if self.optionsFrame then return self.optionsFrame end
    local f = CreateFrame("Frame", "QFXMinimapToolsOptionsFrame", UIParent, BACKDROP_TEMPLATE)
    f:SetSize(OPTION_LAYOUT.panelW, OPTION_LAYOUT.panelH)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        edgeSize = 24,
        insets = {left = 6, right = 6, top = 6, bottom = 6},
    })

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 26, -16)
    title:SetWidth(320)
    title:SetJustifyH("LEFT")
    title:SetText(L.TITLE)
    title:SetTextColor(1, 0.82, 0)
    f.qfxTitle = title

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    local languageOptions = {
        {key = "AUTO", label = L.LANGUAGE_AUTO},
        {key = "zhCN", label = L.LANGUAGE_ZH},
        {key = "enUS", label = L.LANGUAGE_EN},
    }
    f.languageDropdown = MakeDropdown(f, L.UI_LANGUAGE, 420, -18, 88, 142, languageOptions,
        function()
            return QMT:GetLanguageLabel(QMT.db and QMT.db.ui and QMT.db.ui.language or "AUTO")
        end,
        function(key)
            QMT:SetUILanguage(key)
        end)

    local margin = OPTION_LAYOUT.margin
    local labelW = OPTION_LAYOUT.labelW
    local controlW = OPTION_LAYOUT.controlW
    local sliderW = OPTION_LAYOUT.sliderW
    local rowH = OPTION_LAYOUT.rowH

    local mini = MakeSection(f, L.MINIMAP, margin, -56, 330, 282)
    f.minimapSection = mini
    local y = -36
    f.enableEnhanceCheck = MakeCheck(mini, L.ENABLE_ENHANCE, 14, y, function() return QMT.db.minimap.enabled end, function(v) QMT.db.minimap.enabled = v end, 280); y = y - rowH
    f.squareCheck = MakeCheck(mini, L.SQUARE, 14, y, function() return QMT.db.minimap.square end, function(v) QMT.db.minimap.square = v end, 280); y = y - rowH
    f.hideCompartmentCheck = MakeCheck(mini, L.HIDE_COMPARTMENT, 14, y, function() return QMT.db.minimap.hideCompartment end, function(v) QMT.db.minimap.hideCompartment = v end, 280); y = y - rowH
    f.lockMinimapCheck = MakeCheck(mini, L.LOCK_MINIMAP, 14, y, function() return QMT.db.minimap.locked end, function(v) QMT.db.minimap.locked = v end, 280); y = y - rowH - 10

    local borderOptions = {}
    for _, key in ipairs(QMT.borderPresetOrder) do
        local preset = QMT.borderPresets[key]
        if preset then table.insert(borderOptions, {key = key, label = preset.label or key}) end
    end
    f.borderPresetDropdown = MakeDropdown(mini, L.BORDER_STYLE, 16, y, labelW, controlW, borderOptions,
        function()
            local key = QMT.db and QMT.db.minimap and QMT.db.minimap.borderPreset or "DARK"
            return QMT:GetBorderPresetLabel(key)
        end,
        function(key)
            QMT:SetBorderPreset(key)
            QMT:ApplyAll()
        end)
    QMT:RefreshBorderPresetControls()
    y = y - OPTION_LAYOUT.sliderRowH

    f.minimapScaleSlider = MakeSlider(mini, L.MINIMAP_SCALE, 16, y, labelW, sliderW, 0.7, 2.0, 0.05, function() return QMT.db.minimap.scale end, function(v) QMT.db.minimap.scale = v end, function(v) return string.format("%.2f", v) end)
    y = y - OPTION_LAYOUT.sliderRowH
    f.resetMinimapButton = MakeButton(mini, L.RESET_MINIMAP_POSITION, GetControlX(16, labelW), y + 4, 182, 24, function() QMT:ResetMinimapPosition() end)

    local stats = MakeSection(f, L.STATS, margin + 342, -56, 330, 306)
    f.statsSection = stats
    y = -36
    MakeCheck(stats, L.SHOW_LOCATION, 14, y, function() return QMT.db.display.location end, function(v) QMT.db.display.location = v end, 280, RefreshStatsFromOptions); y = y - rowH
    MakeCheck(stats, L.SHOW_COORDS, 14, y, function() return QMT.db.display.coordinates end, function(v) QMT.db.display.coordinates = v end, 280, RefreshStatsFromOptions); y = y - rowH
    MakeCheck(stats, L.SHOW_TIME, 14, y, function() return QMT.db.display.time end, function(v) QMT.db.display.time = v end, 280, RefreshStatsFromOptions); y = y - rowH
    MakeCheck(stats, L.SHOW_SYSTEM, 14, y, function() return QMT.db.display.system end, function(v) QMT.db.display.system = v end, 280, RefreshStatsFromOptions); y = y - rowH
    MakeCheck(stats, L.SHOW_CPU_USAGE, 14, y, function() return QMT.db.performance and QMT.db.performance.disableCPUProfiling ~= false end, function(v) QMT.db.performance = QMT.db.performance or {}; QMT.db.performance.disableCPUProfiling = v and true or false; QMT:ApplyCPUProfilerSetting("user") end, 280, function() end); y = y - rowH
    MakeCheck(stats, L.SHOW_DURABILITY, 14, y, function() return QMT.db.display.durability end, function(v) QMT.db.display.durability = v end, 280, RefreshStatsFromOptions); y = y - rowH
    MakeCheck(stats, L.SHOW_PHASE_ID, 14, y, function() return QMT.db.display.phaseID end, function(v) QMT.db.display.phaseID = v end, 280, RefreshStatsFromOptions); y = y - rowH
    MakeCheck(stats, L.SHOW_DIFFICULTY, 14, y, function() return QMT.db.display.difficulty end, function(v) QMT.db.display.difficulty = v end, 280, RefreshStatsFromOptions); y = y - OPTION_LAYOUT.sliderRowH
    f.fontSizeSlider = MakeSlider(stats, L.FONT_SIZE, 16, y, labelW, sliderW, 8, 22, 1, function() return QMT.db.display.fontSize end, function(v) QMT.db.display.fontSize = v end, function(v) return tostring(v) end, RefreshStatsFromOptions)

    local flight = MakeSection(f, L.FLIGHT_SECTION, margin, -374, 672, 126)
    f.flightSection = flight
    y = -36
    f.flightCenterCheck = MakeCheck(flight, L.FLIGHT_CENTER, 14, y, function() return QMT.db.minimap.flightCenter end, function(v) QMT.db.minimap.flightCenter = v end, 310)
    f.flightAlphaSlider = MakeSlider(flight, L.FLIGHT_ALPHA, 352, y, labelW, sliderW, 0.10, 1.00, 0.05, function() return QMT.db.minimap.flightAlpha end, function(v) QMT.db.minimap.flightAlpha = v end, function(v) return string.format("%.2f", v) end)
    y = y - OPTION_LAYOUT.sliderRowH
    f.flightScaleSlider = MakeSlider(flight, L.FLIGHT_SCALE, 16, y, labelW, sliderW, 1.00, 3.00, 0.05, function() return QMT.db.minimap.flightScale end, function(v) QMT.db.minimap.flightScale = v end, function(v) return string.format("%.2f", v) end)
    f.flightPosYSlider = MakeSlider(flight, L.FLIGHT_POS_Y, 352, y, labelW, sliderW, -240, 40, 1, function() return QMT.db.minimap.flightPosY end, function(v) QMT.db.minimap.flightPosY = v end, function(v) return tostring(math.floor(v + 0.5)) end)

    local bag = MakeSection(f, L.BUTTONS, margin, -512, 672, 180)
    f.bagSection = bag
    y = -36
    f.collectButtonsCheck = MakeCheck(bag, L.COLLECT_BUTTONS, 14, y, function() return QMT.db.bag.enabled end, function(v) QMT.db.bag.enabled = v end, 310)
    f.autoCloseCheck = MakeCheck(bag, L.AUTO_CLOSE, 352, y, function() return QMT.db.bag.autoClose end, function(v) QMT.db.bag.autoClose = v end, 285)
    y = y - OPTION_LAYOUT.sliderRowH
    f.buttonScaleSlider = MakeSlider(bag, L.BUTTON_SCALE, 16, y, labelW, sliderW, 0.7, 1.4, 0.05, function() return QMT.db.bag.buttonScale end, function(v) QMT.db.bag.buttonScale = v end, function(v) return string.format("%.2f", v) end)
    f.buttonsPerRowSlider = MakeSlider(bag, L.BUTTONS_PER_ROW, 352, y, labelW, sliderW, 1, 10, 1, function() return QMT.db.bag.buttonsPerRow end, function(v) QMT.db.bag.buttonsPerRow = v end, function(v) return tostring(v) end)

    y = y - OPTION_LAYOUT.sliderRowH - 4
    f.excludeLabel = MakeRowLabel(bag, L.EXCLUDE, 16, y, 620)
    f.excludeLabel:SetHeight(22)
    y = y - 26
    local eb = CreateFrame("EditBox", nil, bag, "InputBoxTemplate")
    eb:SetPoint("TOPLEFT", 20, y)
    eb:SetSize(622, 22)
    eb:SetAutoFocus(false)
    eb:SetText(QMT.db.bag.exclude or "")
    eb:SetCursorPosition(0)
    eb:SetScript("OnEnterPressed", function(self)
        QMT.db.bag.exclude = self:GetText() or ""
        QMT:InvalidateExcludeCache()
        self:ClearFocus()
        QMT:RestoreCollectedButtons()
        QMT:ApplyAll()
    end)
    eb:SetScript("OnEditFocusLost", function(self)
        QMT.db.bag.exclude = self:GetText() or ""
        QMT:InvalidateExcludeCache()
        QMT:RestoreCollectedButtons()
        QMT:ApplyAll()
    end)
    f.excludeEditBox = eb

    local buttonY = -714
    f.rescanButton = MakeButton(f, L.RESCAN, margin, buttonY, 120, 26, function() QMT:RescanButtons(true) end)
    f.buttonManagerButton = MakeButton(f, L.BUTTON_MANAGER, margin + 132, buttonY, 128, 26, function() QMT:ShowButtonManager() end)
    f.resetButton = MakeButton(f, L.RESET, margin + 272, buttonY, 120, 26, function() QMT:ResetDefaults() end)
    f.reloadButton = MakeButton(f, L.RELOAD, margin + 404, buttonY, 120, 26, function() ReloadUI() end)

    f.minimapDependentControls = {
        f.squareCheck, f.hideCompartmentCheck, f.lockMinimapCheck,
        f.borderPresetDropdown, f.minimapScaleSlider, f.resetMinimapButton,
        f.flightCenterCheck,
    }
    f.flightDependentControls = {
        f.flightAlphaSlider, f.flightScaleSlider, f.flightPosYSlider,
    }
    f.bagDependentControls = {
        f.autoCloseCheck, f.buttonScaleSlider, f.buttonsPerRowSlider,
        f.excludeEditBox, f.excludeLabel, f.rescanButton, f.buttonManagerButton,
    }

    self.optionsFrame = f
    self:RefreshOptionsControlState()
    return f
end

function QMT:ShowOptions()
    self:CreateOptionsFrame():Show()
end

function QMT:ToggleOptions()
    local f = self:CreateOptionsFrame()
    if f:IsShown() then f:Hide() else f:Show() end
end

function QMT:CreateSettingsPanel()
    if self.settingsPanel then return self.settingsPanel end

    local panel = CreateFrame("Frame", "QFXMinimapToolsSettingsPanel", UIParent)
    panel.name = L.TITLE
    panel.parent = nil

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText(L.TITLE)
    panel.qfxTitle = title

    local desc = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    desc:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -10)
    desc:SetWidth(560)
    desc:SetJustifyH("LEFT")
    desc:SetText(L.PANEL_DESC)
    panel.qfxDesc = desc

    local openBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    openBtn:SetPoint("TOPLEFT", desc, "BOTTOMLEFT", 0, -18)
    openBtn:SetSize(220, 28)
    openBtn:SetText(L.OPEN_OPTIONS)
    panel.qfxOpenButton = openBtn
    openBtn:SetScript("OnClick", function() QMT:ShowOptions() end)

    local resetPosBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    resetPosBtn:SetPoint("LEFT", openBtn, "RIGHT", 10, 0)
    resetPosBtn:SetSize(210, 28)
    resetPosBtn:SetText(L.RESET_MINIMAP_POSITION)
    panel.qfxResetPosButton = resetPosBtn
    resetPosBtn:SetScript("OnClick", function() QMT:ResetMinimapPosition() end)

    local cmd = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    cmd:SetPoint("TOPLEFT", openBtn, "BOTTOMLEFT", 0, -16)
    cmd:SetWidth(560)
    cmd:SetJustifyH("LEFT")
    cmd:SetText(L.COMMAND_HINT)
    panel.qfxCommandHint = cmd

    self.settingsPanel = panel
    return panel
end

function QMT:RegisterSettingsCategory()
    if self.settingsRegistered then return true end

    local panel = self:CreateSettingsPanel()
    local registered = false

    -- Retail / modern Options -> AddOns.
    if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
        local category = Settings.RegisterCanvasLayoutCategory(panel, L.TITLE)
        Settings.RegisterAddOnCategory(category)
        self.settingsCategory = category
        self.settingsCategoryID = category and category.ID
        registered = true
    -- Legacy Interface Options fallback.
    elseif InterfaceOptions_AddCategory then
        InterfaceOptions_AddCategory(panel)
        registered = true
    end

    if registered then
        self.settingsRegistered = true
        return true
    end

    -- Some clients load the Settings system a little later. Retry instead of
    -- marking registration as complete and silently disappearing from Options.
    if C_Timer and not self.settingsRegisterRetryQueued then
        self.settingsRegisterRetryQueued = true
        C_Timer.After(1, function()
            QMT.settingsRegisterRetryQueued = nil
            QMT:RegisterSettingsCategory()
        end)
    end
    return false
end

function QMT:OpenBlizzardSettingsCategory()
    self:RegisterSettingsCategory()
    if Settings and Settings.OpenToCategory and self.settingsCategoryID then
        Settings.OpenToCategory(self.settingsCategoryID)
    elseif InterfaceOptionsFrame_OpenToCategory and self.settingsPanel then
        -- Calling twice is a common legacy UI workaround to focus the right panel.
        InterfaceOptionsFrame_OpenToCategory(self.settingsPanel)
        InterfaceOptionsFrame_OpenToCategory(self.settingsPanel)
    else
        self:ShowOptions()
    end
end

-- ############################################################
