local ADDON_NAME, QMT = ...
QMT = QMT or {}

local DeepCopy = QMT.DeepCopy
local MergeDefaults = QMT.MergeDefaults
local NormalizeLanguageChoice = QMT.NormalizeLanguageChoice
local Print = QMT.Print
local L = setmetatable({}, { __index = function(_, key) return QMT.L and QMT.L[key] end })

local defaults = {
    version = 27,
    ui = {
        language = "AUTO",
    },
    minimap = {
        enabled = true,
        square = true,
        scale = 1.20,
        unclamp = true,
        hideCompartment = true,
        borderSize = 3,
        borderPreset = "AUTO_SKIN",
        borderColor = {0.18, 0.18, 0.18, 1},
        borderEdgeFile = nil,
        autoSnap = true,
        locked = true,
        manualPoint = nil,
        flightCenter = true,
        flightScale = 2.10,
        flightPosY = -55,
        flightAlpha = 0.50,
        flightCenterOnlyGathering = true,
        -- Keep the visible border and one border-width gap inside the screen.
        snapX = -9,
        snapY = -9,
    },
    bag = {
        enabled = true,
        autoClose = false,
        buttonScale = 1.00,
        buttonsPerRow = 8,
        mainButtonOffsetY = 0,
        mainButtonEdge = "LEFT",
        mainButtonOffset = 0,
        manualExclude = {},
        exclude = "MiniMapTracking,MiniMapMailFrame,MiniMapWorldMapButton,MinimapZoomIn,MinimapZoomOut,GameTimeFrame,TimeManagerClockButton,QueueStatusButton,QueueStatusMinimapButton,AddonCompartmentFrame,ExpansionLandingPageMinimapButton,GarrisonLandingPageMinimapButton",
    },
    performance = {
        disableCPUProfiling = true,
        addonCount = 8,
    },
    display = {
        fontSize = 12,
        font = "Fonts\\FRIZQT__.TTF",
        outline = "OUTLINE",
        shadow = true,
        accent = {0.5019608, 0.5019608, 1.00},
        location = true,
        coordinates = true,
        time = true,
        system = true,
        durability = false,
        phaseID = false,
        difficulty = true,
        coordsDecimals = 1,
        coordsInterval = 1.00,
        systemInterval = 3.00,
        systemString = "%fps | %home",
        timeInterval = 5.00,
        useRealmTime = false,
        use12Hour = false,
        showSubZone = true,
    },
}

function QMT:LoadDB()
    QFXMinimapToolsDB = MergeDefaults(QFXMinimapToolsDB, DeepCopy(defaults))
    self.db = QFXMinimapToolsDB
    self:InvalidateExcludeCache()

    -- 1.0.1 migration: make square minimap and visible button bag the default for existing users too.
    if not self.db.version or self.db.version < 2 then
        self.db.version = 2
        self.db.minimap.square = true
        self.db.minimap.unclamp = true
        self.db.bag.enabled = true
    end

    -- 1.0.2 migration: clean square-map header art, move stats into non-overlapping positions,
    -- and place the bag trigger as a small Q on the left edge of the square minimap.
    if not self.db.version or self.db.version < 3 then
        self.db.version = 3
        self.db.minimap.square = true
        self.db.minimap.unclamp = true
        self.db.minimap.hideCompartment = true
        self.db.bag.enabled = true
        self.db.bag.mainButtonOffsetY = 0
    end

    -- 1.0.3 migration: snap the actual minimap to the top-right corner with no visual gap,
    -- use MinimapStats-style system text by default, and add per-button selection storage.
    if not self.db.version or self.db.version < 4 then
        self.db.version = 4
        self.db.minimap.square = true
        self.db.minimap.unclamp = true
        self.db.minimap.autoSnap = true
        self.db.minimap.snapX = 0
        self.db.minimap.snapY = 0
        self.db.bag.enabled = true
        self.db.bag.buttonsPerRow = 8
        self.db.bag.manualExclude = self.db.bag.manualExclude or {}
        self.db.display.systemString = "%fps | %home"
        self.db.display.systemInterval = 3.0
        self.db.display.durability = false
    end

    -- 1.0.4 migration: keep the square border visible at the top-right edge,
    -- scale the actual Minimap frame instead of only MinimapCluster, and make the
    -- button bag follow the Q trigger.
    if not self.db.version or self.db.version < 5 then
        self.db.version = 5
        self.db.minimap.square = true
        self.db.minimap.unclamp = true
        self.db.minimap.autoSnap = true
        local pad = tonumber(self.db.minimap.borderSize) or 3
        self.db.minimap.snapX = -pad
        self.db.minimap.snapY = -pad
        self.db.bag.enabled = true
        self.db.bag.manualExclude = self.db.bag.manualExclude or {}
    end

    -- 1.0.5 migration: move the map inward enough that the custom square border
    -- is never clipped, and switch FPS/MS to the spaced MinimapStats-like text.
    if not self.db.version or self.db.version < 6 then
        self.db.version = 6
        self.db.minimap.square = true
        self.db.minimap.unclamp = true
        self.db.minimap.autoSnap = true
        local border = tonumber(self.db.minimap.borderSize) or 3
        local inset = math.max(border * 3, 9)
        self.db.minimap.snapX = -inset
        self.db.minimap.snapY = -inset
        self.db.display.systemString = "%fps    %home"
        self.db.bag.enabled = true
        self.db.bag.manualExclude = self.db.bag.manualExclude or {}
    end

    -- 1.0.6 migration: default minimap scale is 1.2, restore the MinimapStats-style
    -- separator in the FPS/MS line, and add locked/manual minimap movement.
    if not self.db.version or self.db.version < 7 then
        self.db.version = 7
        self.db.minimap.square = true
        self.db.minimap.unclamp = true
        self.db.minimap.scale = 1.20
        self.db.minimap.locked = true
        self.db.minimap.autoSnap = true
        self.db.minimap.manualPoint = nil
        local border = tonumber(self.db.minimap.borderSize) or 3
        local inset = math.max(border * 3, 9)
        self.db.minimap.snapX = -inset
        self.db.minimap.snapY = -inset
        self.db.display.accent = {0.5019608, 0.5019608, 1.00}
        self.db.display.systemString = "%fps | %home"
        self.db.bag.enabled = true
        self.db.bag.manualExclude = self.db.bag.manualExclude or {}
    end

    -- 1.0.7 migration: action-bar border following was tested but later removed
    -- because different action-bar skin addons expose borders inconsistently.
    if not self.db.version or self.db.version < 8 then
        self.db.version = 8
    end

    -- 1.0.9 migration: replace action-bar border following with fixed color
    -- presets and an open skin API for other addons.
    if not self.db.version or self.db.version < 10 then
        self.db.version = 10
        self.db.minimap.borderPreset = self.db.minimap.borderPreset or "DARK"
        self.db.minimap.borderColor = self.db.minimap.borderColor or {0, 0, 0, 1}
        self.db.minimap.borderEdgeFile = nil
    end

    -- 1.0.10 migration: switch the visible square border to solid tintable
    -- line textures. Some backdrop edge textures are dark and do not visibly
    -- change color when tinted, so color presets now repaint real border lines.
    if not self.db.version or self.db.version < 11 then
        self.db.version = 11
        self.db.minimap.borderPreset = self.db.minimap.borderPreset or "DARK"
        if not self.borderPresets or not self.borderPresets[self.db.minimap.borderPreset] then
            self.db.minimap.borderPreset = "BLACK"
        end
        self.db.minimap.borderEdgeFile = nil
    end

    -- 1.0.11 migration: dark gray is the new default border color and the
    -- options UI can be forced to Chinese/English or follow the client locale.
    if not self.db.version or self.db.version < 12 then
        self.db.version = 12
        self.db.ui = self.db.ui or {}
        self.db.ui.language = NormalizeLanguageChoice(self.db.ui.language)
        if self.db.minimap.borderPreset == nil or self.db.minimap.borderPreset == "BLACK" then
            self.db.minimap.borderPreset = "DARK"
            self.db.minimap.borderColor = {0.18, 0.18, 0.18, 1}
        end
    end

    -- 1.0.17 migration: performance tooltip shows memory/latency on FPS/MS hover.
    -- CPU addon usage is intentionally opt-in because updating CPU stats can add overhead.
    if not self.db.version or self.db.version < 17 then
        self.db.version = 17
        self.db.performance = self.db.performance or {}
        self.db.performance.addonCount = self.db.performance.addonCount or 8
    end

    -- 1.0.18 migration: make external skin handoff the default for the minimap border
    -- and button-bag frames. Existing custom selections are preserved unless they are
    -- the previous default dark border.
    if not self.db.version or self.db.version < 18 then
        self.db.version = 18
        self.db.minimap = self.db.minimap or {}
        if self.db.minimap.borderPreset == nil or self.db.minimap.borderPreset == "DARK" then
            self.db.minimap.borderPreset = "AUTO_SKIN"
        end
    end


    -- 1.0.20 migration: the CPU option now controls the global WoW addon CPU
    -- profiler instead of merely hiding this addon's CPU value. Keep it enabled
    -- by default to minimize overhead for all addons.
    if not self.db.version or self.db.version < 20 then
        self.db.version = 20
        self.db.performance = self.db.performance or {}
        self.db.performance.disableCPUProfiling = true
        self.db.performance.addonCount = self.db.performance.addonCount or 8
    end
    -- 1.0.22 migration: Q bag trigger now slides on the square minimap border
    -- instead of using a free cursor position. Keep existing vertical offset on the left edge.
    if not self.db.version or self.db.version < 22 then
        self.db.version = 22
        self.db.bag = self.db.bag or {}
        self.db.bag.mainButtonEdge = self.db.bag.mainButtonEdge or "LEFT"
        self.db.bag.mainButtonOffset = tonumber(self.db.bag.mainButtonOffset or self.db.bag.mainButtonOffsetY or 0) or 0
    end

    -- 1.0.29 migration: phase row is fully wired into the live display path.
    -- Keep the option disabled by default for existing users.
    if not self.db.version or self.db.version < 24 then
        self.db.version = 24
        self.db.display = self.db.display or {}
        if type(self.db.display.phaseID) ~= "boolean" then
            self.db.display.phaseID = false
        end
    end

    -- 1.0.35 migration: outdoor flying can temporarily move the minimap to the top center.
    -- Rest areas, instances, taxi flight, and vehicles keep the regular minimap layout.
    if not self.db.version or self.db.version < 25 then
        self.db.version = 25
        self.db.minimap = self.db.minimap or {}
        if type(self.db.minimap.flightCenter) ~= "boolean" then self.db.minimap.flightCenter = true end
        if type(self.db.minimap.flightScale) ~= "number" then self.db.minimap.flightScale = 2.10 end
        if type(self.db.minimap.flightPosY) ~= "number" then self.db.minimap.flightPosY = -55 end
        if type(self.db.minimap.flightAlpha) ~= "number" then self.db.minimap.flightAlpha = 0.50 end
    end

    -- 1.0.39 migration: options UI was rebuilt into a simpler tabbed layout.
    if not self.db.version or self.db.version < 26 then
        self.db.version = 26
        self.db.ui = self.db.ui or {}
        self.db.ui.language = NormalizeLanguageChoice(self.db.ui.language)
    end

    -- 1.0.40 migration: gathering-profession gated flight center is enabled by default.
    -- Players without Herbalism or Mining can untick this to keep the old always-center behavior.
    if not self.db.version or self.db.version < 27 then
        self.db.version = 27
        self.db.minimap = self.db.minimap or {}
        if type(self.db.minimap.flightCenterOnlyGathering) ~= "boolean" then
            self.db.minimap.flightCenterOnlyGathering = true
        end
    end
    self.db.display = self.db.display or {}
    if type(self.db.display.font) ~= "string" or self.db.display.font == "" then
        self.db.display.font = "AUTO"
    end
    if tonumber(self.db.display.coordsInterval or 0) < 1.00 then
        self.db.display.coordsInterval = 1.00
    end

    if self.RefreshLocale then self:RefreshLocale() end
end

function QMT:ResetDefaults()
    QFXMinimapToolsDB = DeepCopy(defaults)
    self.db = QFXMinimapToolsDB
    self:InvalidateExcludeCache()
    if self.RefreshLocale then self:RefreshLocale() end
    self:ApplyAll()
    if self.optionsFrame then self.optionsFrame:Hide() self.optionsFrame = nil self:ShowOptions() end
    Print(L.RESET_DONE)
end
