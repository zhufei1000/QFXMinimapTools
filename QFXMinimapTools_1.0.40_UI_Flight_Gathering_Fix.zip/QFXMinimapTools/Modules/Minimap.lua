local ADDON_NAME, QMT = ...
QMT = QMT or {}
_G.QFXMinimapTools = QMT

local L = setmetatable({}, { __index = function(_, key) return QMT.L and QMT.L[key] end })
local SafeCall = QMT.SafeCall
local Clamp = QMT.Clamp
local Round = QMT.Round
local AccentHex = QMT.AccentHex
local DisplayAccentHex = QMT.DisplayAccentHex
local ColorText = QMT.ColorText
local IsDescendant = QMT.IsDescendant
local Print = QMT.Print
local NormalizeLanguageChoice = QMT.NormalizeLanguageChoice
local SelectLocale = QMT.SelectLocale

function QMT:ResetMinimapPosition()
    if not self.db or not self.db.minimap then return end
    local db = self.db.minimap
    db.autoSnap = true
    db.locked = true
    db.manualPoint = nil
    local inset = self:GetSnapInset()
    db.snapX = -inset
    db.snapY = -inset
    self:ApplyAll()
    if self.optionsFrame then self.optionsFrame:Hide() self.optionsFrame = nil self:ShowOptions() end
    Print(L.POSITION_RESET_DONE)
end

-- ############################################################
-- Minimap enhancement
-- ############################################################

local roundMinimapArtNames = {
    "MinimapBorder",
    "MinimapBorderTop",
    "MinimapBackdrop",
    "MiniMapMailBorder",
    "MiniMapBattlefieldBorder",
    "MinimapNorthTag",
}

local function LooksLikeRoundMinimapArt(region)
    if not region or not region.GetTexture then return false end
    local tex = region:GetTexture()
    if type(tex) ~= "string" then return false end
    tex = tex:lower()
    if tex:find("qfxminimaptools", 1, true) then return false end
    if tex:find("border", 1, true) or tex:find("arch", 1, true) or tex:find("minimap%-trackingborder") then
        return tex:find("minimap", 1, true) or tex:find("mini%-map", 1, true) or tex:find("trackingborder", 1, true)
    end
    return false
end

function QMT:CaptureRoundMinimapArt()
    if self.roundMinimapArtCaptured then return end
    self.roundMinimapArtCaptured = true
    self.roundMinimapArt = {}

    local function AddArt(obj)
        if not obj or obj == self.squareBorder or self.roundMinimapArt[obj] then return end
        if obj.GetObjectType and obj:GetObjectType() == "Frame" and obj.GetName and tostring(obj:GetName() or ""):find("QFXMinimapTools") then return end
        self.roundMinimapArt[obj] = {
            alpha = obj.GetAlpha and obj:GetAlpha() or 1,
            shown = obj.IsShown and obj:IsShown() or true,
        }
    end

    for _, name in ipairs(roundMinimapArtNames) do AddArt(_G[name]) end
    if MinimapCluster then
        AddArt(MinimapCluster.BorderTop)
        AddArt(MinimapCluster.BorderBottom)
    end
    if Minimap then
        for _, region in ipairs({Minimap:GetRegions()}) do
            if LooksLikeRoundMinimapArt(region) then AddArt(region) end
        end
    end
    if MinimapCluster then
        for _, region in ipairs({MinimapCluster:GetRegions()}) do
            if LooksLikeRoundMinimapArt(region) then AddArt(region) end
        end
    end
end

function QMT:SetRoundMinimapArtHidden(hidden)
    self:CaptureRoundMinimapArt()
    for obj, info in pairs(self.roundMinimapArt or {}) do
        if obj and obj.SetAlpha then
            if hidden then
                obj:SetAlpha(0)
                if obj.Hide then obj:Hide() end
            else
                obj:SetAlpha(info.alpha or 1)
                if info.shown and obj.Show then obj:Show() end
            end
        end
    end
end

local nativeMinimapControlNames = {
    -- Default header / title / time / tracking / zoom / top overlay controls.
    "MinimapZoneTextButton",
    "MinimapZoneText",
    "MinimapToggleButton",
    "MinimapCompassTexture",
    "MiniMapWorldMapButton",
    "MinimapZoomIn",
    "MinimapZoomOut",
    "TimeManagerClockButton",
    "GameTimeFrame",
    "AddonCompartmentFrame",
    "ExpansionLandingPageMinimapButton",
    "GarrisonLandingPageMinimapButton",
    -- Default instance/difficulty badges. QFX draws its own difficulty text in the top-left corner.
    "MiniMapInstanceDifficulty",
    "GuildInstanceDifficulty",
    "MiniMapChallengeMode",
}

function QMT:ShouldCleanSquareMinimap()
    return self.db and self.db.minimap and self.db.minimap.enabled and self.db.minimap.square
end

function QMT:CaptureNativeMinimapControls()
    if self.nativeMinimapControlsCaptured then return end
    self.nativeMinimapControlsCaptured = true
    self.nativeMinimapControls = {}

    local function AddObj(obj)
        if not obj or obj == self.bagButton or obj == self.bagFrame or obj == self.squareBorder then return end
        if self.nativeMinimapControls[obj] then return end
        self.nativeMinimapControls[obj] = {
            alpha = obj.GetAlpha and obj:GetAlpha() or 1,
            shown = obj.IsShown and obj:IsShown() or false,
        }
        if obj.HookScript and not obj.QFXMinimapToolsCleanHook then
            obj:HookScript("OnShow", function(frame)
                if QMT:ShouldCleanSquareMinimap() and frame.Hide then frame:Hide() end
            end)
            obj.QFXMinimapToolsCleanHook = true
        end
    end

    for _, name in ipairs(nativeMinimapControlNames) do AddObj(_G[name]) end

    if MinimapCluster then
        AddObj(MinimapCluster.ZoneTextButton)
        AddObj(MinimapCluster.BorderTop)
        AddObj(MinimapCluster.BorderBottom)
        AddObj(MinimapCluster.IndicatorFrame)
        AddObj(MinimapCluster.InstanceDifficulty)
        AddObj(MinimapCluster.AddonCompartmentFrame)
        AddObj(MinimapCluster.MinimapContainer and MinimapCluster.MinimapContainer.Header)
    end

    if Minimap then
        for _, region in ipairs({Minimap:GetRegions()}) do
            if LooksLikeRoundMinimapArt(region) then AddObj(region) end
        end
    end
end

function QMT:SetNativeMinimapControlsHidden(hidden)
    self:CaptureNativeMinimapControls()
    for obj, info in pairs(self.nativeMinimapControls or {}) do
        if obj then
            if hidden then
                if obj.SetAlpha then obj:SetAlpha(0) end
                if obj.Hide then obj:Hide() end
            else
                if obj.SetAlpha then obj:SetAlpha(info.alpha or 1) end
                if info.shown and obj.Show then obj:Show() end
            end
        end
    end
end

function QMT:GetSnapInset()
    local border = self.db and self.db.minimap and tonumber(self.db.minimap.borderSize) or 3
    -- The border frame extends outside the Minimap. Use a larger automatic inset so
    -- the border itself plus a small gap remains visible at any UI scale.
    return math.max(border * 3, 9)
end

function QMT:CreateSnapAnchor()
    if self.snapAnchor then return self.snapAnchor end
    local anchor = CreateFrame("Frame", "QFXMinimapToolsTopRightAnchor", UIParent)
    anchor:SetSize(1, 1)
    local inset = self:GetSnapInset()
    anchor:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -inset, -inset)
    self.snapAnchor = anchor
    return anchor
end

function QMT:UpdateSquareBorderPosition()
    if self.squareBorder and Minimap then
        self.squareBorder:SetFrameStrata("LOW")
        if self.squareBorder.SetFrameLevel and Minimap.GetFrameLevel then
            self.squareBorder:SetFrameLevel(math.max(0, (Minimap:GetFrameLevel() or 1) - 1))
        end
        self.squareBorder:ClearAllPoints()
        self.squareBorder:SetPoint("TOPLEFT", Minimap, "TOPLEFT", -3, 3)
        self.squareBorder:SetPoint("BOTTOMRIGHT", Minimap, "BOTTOMRIGHT", 3, -3)
    end
end

function QMT:RefreshMinimapAttachedElements(updateStats, layoutBag)
    SafeCall(self.ApplyQueueStatusButtonPosition, self)
    SafeCall(self.ApplyMailFramePosition, self)
    SafeCall(self.ApplyTrackingButtonPosition, self)
    if self.ApplyNativeControlSkin then SafeCall(self.ApplyNativeControlSkin, self) end
    SafeCall(self.PlaceBagButton, self)
    if self.statFrames then
        if self.PlaceAllStatFrames then
            SafeCall(self.PlaceAllStatFrames, self)
        else
            for key in pairs(self.statFrames) do SafeCall(self.PlaceStatFrame, self, key) end
        end
        if updateStats then SafeCall(self.UpdateAllStats, self) end
    end
    if layoutBag and self.bagFrame and self.bagFrame:IsShown() then SafeCall(self.LayoutBag, self) end
end

function QMT:RequestAttachedElementRefresh(updateStats, layoutBag)
    self.refreshStatsQueued = self.refreshStatsQueued or updateStats
    self.refreshBagLayoutQueued = self.refreshBagLayoutQueued or layoutBag
    if self.attachedRefreshQueued then return end
    self.attachedRefreshQueued = true
    local function Flush()
        QMT.attachedRefreshQueued = false
        local doStats = QMT.refreshStatsQueued
        local doLayout = QMT.refreshBagLayoutQueued
        QMT.refreshStatsQueued = false
        QMT.refreshBagLayoutQueued = false
        SafeCall(QMT.RefreshMinimapAttachedElements, QMT, doStats, doLayout)
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(0, Flush)
    else
        Flush()
    end
end


function QMT:GetManagedNativeQueueFrame()
    -- Retail clients can expose more than one queue-eye frame name. The minimap-era
    -- QueueStatusMinimapButton is the one that belongs on the minimap; QueueStatusButton
    -- may still exist for other Blizzard UI paths and must not be dragged on top of it.
    return _G.QueueStatusMinimapButton or _G.QueueStatusButton
end


function QMT:CaptureNativeQueueFrame(frame)
    if not frame then return end
    self.queueStatusOriginal = self.queueStatusOriginal or {}
    if self.queueStatusOriginal[frame] then return end
    self.queueStatusOriginal[frame] = {
        parent = frame.GetParent and frame:GetParent(),
        point = {frame:GetPoint(1)},
        scale = frame.GetScale and frame:GetScale() or 1,
        width = frame.GetWidth and frame:GetWidth(),
        height = frame.GetHeight and frame:GetHeight(),
        alpha = frame.GetAlpha and frame:GetAlpha() or 1,
        shown = frame.IsShown and frame:IsShown() or false,
    }
end

local function QFXRestoreNativeQueueFrame(frame, original)
    if not frame or not original then return end
    SafeCall(frame.SetParent, frame, original.parent or MinimapCluster or Minimap)
    SafeCall(frame.ClearAllPoints, frame)
    if original.point and original.point[1] then
        SafeCall(frame.SetPoint, frame, unpack(original.point))
    end
    if original.scale and frame.SetScale then SafeCall(frame.SetScale, frame, original.scale) end
    if original.width and original.height and frame.SetSize then
        SafeCall(frame.SetSize, frame, original.width, original.height)
    end
    if frame.SetAlpha then SafeCall(frame.SetAlpha, frame, original.alpha or 1) end
    if original.shown then
        if frame.Show then SafeCall(frame.Show, frame) end
    else
        if frame.Hide then SafeCall(frame.Hide, frame) end
    end
end


function QMT:ApplyQueueStatusButtonPosition()
    if not Minimap then return end
    local q = self:GetManagedNativeQueueFrame()
    if not q then return end

    if not self:ShouldCleanSquareMinimap() then
        QFXRestoreNativeQueueFrame(q, self.queueStatusOriginal and self.queueStatusOriginal[q])
        return
    end

    self:CaptureNativeQueueFrame(q)

    -- Only relocate Blizzard's minimap queue-eye. Never call Show() here: Blizzard owns
    -- the queue state and display timing. Forcing Show() makes the eye flash even when the
    -- player has not queued for anything.
    SafeCall(q.SetParent, q, Minimap)
    SafeCall(q.ClearAllPoints, q)
    SafeCall(q.SetPoint, q, "BOTTOMLEFT", Minimap, "BOTTOMLEFT", 2, 2)
    SafeCall(q.SetSize, q, 24, 24)
    SafeCall(q.SetScale, q, 0.5)
    SafeCall(q.SetFrameStrata, q, "HIGH")
    if q.SetFrameLevel and Minimap.GetFrameLevel then
        SafeCall(q.SetFrameLevel, q, (Minimap:GetFrameLevel() or 0) + 35)
    end
    if q.SetAlpha then SafeCall(q.SetAlpha, q, 1) end

    if q.HookScript and not q.QFXMinimapToolsQueueHooked then
        q:HookScript("OnShow", function()
            QMT:ApplyQueueStatusButtonPosition()
            if QMT.statFrames and QMT.statFrames.system then QMT:PlaceStatFrame("system") end
        end)
        q:HookScript("OnHide", function()
            if QMT.statFrames and QMT.statFrames.system then QMT:PlaceStatFrame("system") end
        end)
        q.QFXMinimapToolsQueueHooked = true
    end
end

local function QFXHasNewMail()
    if HasNewMail then
        local hasMail = SafeCall(HasNewMail)
        if hasMail ~= nil then return hasMail and true or false end
    end
    local mail = _G.MiniMapMailFrame
    return mail and mail.IsShown and mail:IsShown() or false
end

function QMT:ShouldUseCustomMailIndicator()
    return self.db
        and self.db.minimap
        and self.db.minimap.enabled
        and self.db.minimap.square
        and Minimap
end

function QMT:GetMailIndicator()
    if self.mailIndicator then return self.mailIndicator end
    if not Minimap then return nil end

    -- Addon-owned clean mail icon. It intentionally has no circular tracking border:
    -- the icon sits on the square minimap edge like a compact edge marker.
    local frame = CreateFrame("Frame", "QFXMinimapToolsMailIndicator", Minimap)
    frame:SetSize(20, 15)
    frame:EnableMouse(true)
    frame:SetFrameStrata("HIGH")
    if frame.SetFrameLevel and Minimap.GetFrameLevel then
        frame:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 38)
    end

    local icon = frame:CreateTexture(nil, "ARTWORK")
    if icon.SetAtlas then
        icon:SetAtlas("ui-hud-minimap-mail-up", true)
    else
        icon:SetTexture("Interface\\Minimap\\MiniMap-MailIcon")
        icon:SetSize(20, 15)
    end
    icon:SetPoint("CENTER", frame, "CENTER", 0, 0)
    frame.Icon = icon

    frame:SetScript("OnEnter", function(owner)
        if not GameTooltip then return end
        GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
        GameTooltip:SetText(L.MAIL_PENDING or "New mail")
        if type(_G.MinimapMailFrameUpdate) == "function" then
            SafeCall(_G.MinimapMailFrameUpdate)
        end
        GameTooltip:Show()
    end)
    frame:SetScript("OnLeave", function()
        if GameTooltip_Hide then
            GameTooltip_Hide()
        elseif GameTooltip then
            GameTooltip:Hide()
        end
    end)
    frame:Hide()

    self.mailIndicator = frame
    return frame
end

function QMT:CaptureNativeMailFrame()
    local mail = _G.MiniMapMailFrame
    if not mail or self.mailFrameOriginal then return end
    self.mailFrameOriginal = {
        parent = mail.GetParent and mail:GetParent(),
        point = {mail:GetPoint(1)},
        scale = mail.GetScale and mail:GetScale() or 1,
        width = mail.GetWidth and mail:GetWidth(),
        height = mail.GetHeight and mail:GetHeight(),
        alpha = mail.GetAlpha and mail:GetAlpha() or 1,
    }
end

function QMT:RestoreNativeMailFrame()
    local mail = _G.MiniMapMailFrame
    local original = self.mailFrameOriginal
    if not mail or not original then return end

    SafeCall(mail.SetParent, mail, original.parent or MinimapCluster or Minimap)
    SafeCall(mail.ClearAllPoints, mail)
    if original.point and original.point[1] then
        SafeCall(mail.SetPoint, mail, unpack(original.point))
    end
    if original.scale then SafeCall(mail.SetScale, mail, original.scale) end
    if original.width and original.height and mail.SetSize then
        SafeCall(mail.SetSize, mail, original.width, original.height)
    end
    if mail.SetAlpha then SafeCall(mail.SetAlpha, mail, original.alpha or 1) end
end

function QMT:ApplyMailFramePosition()
    local hasMail = QFXHasNewMail()
    local useCustom = self:ShouldUseCustomMailIndicator()
    local mail = _G.MiniMapMailFrame
    local indicator = self:GetMailIndicator()

    if useCustom then
        self:CaptureNativeMailFrame()

        -- Suppress the native frame while the square minimap layout is active.
        -- The addon-owned icon is mounted on the left border above the fixed Q trigger.
        if mail then
            if mail.SetAlpha then SafeCall(mail.SetAlpha, mail, 0) end
            if mail.Hide then SafeCall(mail.Hide, mail) end
            if mail.HookScript and not mail.QFXMinimapToolsMailSuppressHooked then
                mail:HookScript("OnShow", function(frame)
                    if not QMT:ShouldUseCustomMailIndicator() then return end
                    local function HideNativeMailAgain()
                        if QMT:ShouldUseCustomMailIndicator() then
                            if frame.SetAlpha then SafeCall(frame.SetAlpha, frame, 0) end
                            if frame.Hide then SafeCall(frame.Hide, frame) end
                            SafeCall(QMT.ApplyMailFramePosition, QMT)
                        end
                    end
                    if C_Timer and C_Timer.After then
                        C_Timer.After(0, HideNativeMailAgain)
                    else
                        HideNativeMailAgain()
                    end
                end)
                mail.QFXMinimapToolsMailSuppressHooked = true
            end
        end

        if indicator then
            local mapHeight = Minimap.GetHeight and Minimap:GetHeight() or 198
            local quarterAboveQ = (tonumber(mapHeight) or 198) * 0.25
            indicator:ClearAllPoints()
            -- X=0 centers the icon exactly on the left edge: half inside, half outside.
            -- Y=25% of minimap height places it one quarter-edge length above the Q trigger.
            indicator:SetPoint("CENTER", Minimap, "LEFT", 0, quarterAboveQ)
            indicator:SetFrameStrata("HIGH")
            if indicator.SetFrameLevel and Minimap.GetFrameLevel then
                indicator:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 38)
            end
            if hasMail then indicator:Show() else indicator:Hide() end
        end
    else
        if indicator then indicator:Hide() end
        self:RestoreNativeMailFrame()
    end
end


function QMT:ShouldUseNativeTrackingCorner()
    return self.db
        and self.db.minimap
        and self.db.minimap.enabled
        and self.db.minimap.square
        and Minimap
end

function QMT:GetNativeTrackingFrame()
    if MinimapCluster and MinimapCluster.Tracking then
        return MinimapCluster.Tracking
    end
    return _G.MiniMapTracking
end

function QMT:CaptureNativeTrackingFrame()
    local tracking = self:GetNativeTrackingFrame()
    if not tracking or self.trackingFrameOriginal then return end
    self.trackingFrameOriginal = {
        parent = tracking.GetParent and tracking:GetParent(),
        point = {tracking:GetPoint(1)},
        scale = tracking.GetScale and tracking:GetScale() or 1,
        width = tracking.GetWidth and tracking:GetWidth(),
        height = tracking.GetHeight and tracking:GetHeight(),
        alpha = tracking.GetAlpha and tracking:GetAlpha() or 1,
    }
end

local function QFXTrackingBorderKey(region)
    if not region then return "" end
    local name = region.GetName and region:GetName() or ""
    local texture = region.GetTexture and region:GetTexture()
    return string.lower(tostring(name or "") .. " " .. tostring(texture or ""))
end

local function QFXLooksLikeTrackingOuterBorder(region)
    local key = QFXTrackingBorderKey(region)
    if key == "" then return false end
    if key:find("trackingborder", 1, true) then return true end
    if key:find("tracking_border", 1, true) then return true end
    if key:find("minimap-trackingborder", 1, true) then return true end
    if key:find("minimap_trackingborder", 1, true) then return true end
    if key:find("tracking", 1, true) and key:find("border", 1, true) then return true end
    return false
end

local function QFXRememberAndHideTrackingOuterBorder(region)
    if not region then return end
    if not region.QFXMinimapToolsTrackingBorderOriginal then
        region.QFXMinimapToolsTrackingBorderOriginal = {
            alpha = region.GetAlpha and region:GetAlpha() or 1,
            shown = region.IsShown and region:IsShown() or false,
        }
    end
    if region.SetAlpha then SafeCall(region.SetAlpha, region, 0) end
    if region.Hide then SafeCall(region.Hide, region) end
end

local function QFXRestoreTrackingOuterBorderRegion(region)
    if not region then return end
    local original = region.QFXMinimapToolsTrackingBorderOriginal
    if not original then return end
    if region.SetAlpha then SafeCall(region.SetAlpha, region, original.alpha or 1) end
    if original.shown then
        if region.Show then SafeCall(region.Show, region) end
    else
        if region.Hide then SafeCall(region.Hide, region) end
    end
end

local function QFXWalkTrackingOuterBorderRegions(frame, callback)
    if not frame or type(callback) ~= "function" then return end
    local seen = {}
    local function Visit(region)
        if not region or seen[region] then return end
        seen[region] = true
        if QFXLooksLikeTrackingOuterBorder(region) then
            callback(region)
        end
    end

    Visit(_G.MiniMapTrackingButtonBorder)
    Visit(_G.MiniMapTrackingBorder)
    Visit(frame.Border)
    Visit(frame.border)

    if frame.GetRegions then
        for _, region in ipairs({frame:GetRegions()}) do Visit(region) end
    end
    if frame.GetChildren then
        for _, child in ipairs({frame:GetChildren()}) do
            if child and child.GetRegions then
                for _, region in ipairs({child:GetRegions()}) do Visit(region) end
            end
        end
    end
end

function QMT:HideNativeTrackingOuterBorder()
    local tracking = self:GetNativeTrackingFrame()
    if not tracking then return end
    QFXWalkTrackingOuterBorderRegions(tracking, QFXRememberAndHideTrackingOuterBorder)
end

function QMT:RestoreNativeTrackingOuterBorder()
    local tracking = self:GetNativeTrackingFrame()
    if not tracking then return end
    QFXWalkTrackingOuterBorderRegions(tracking, QFXRestoreTrackingOuterBorderRegion)
end

function QMT:RestoreNativeTrackingFrame()
    local tracking = self:GetNativeTrackingFrame()
    local original = self.trackingFrameOriginal
    if not tracking or not original then
        self:RestoreNativeTrackingOuterBorder()
        return
    end

    SafeCall(tracking.SetParent, tracking, original.parent or MinimapCluster or Minimap)
    SafeCall(tracking.ClearAllPoints, tracking)
    if original.point and original.point[1] then
        SafeCall(tracking.SetPoint, tracking, unpack(original.point))
    end
    if original.scale then SafeCall(tracking.SetScale, tracking, original.scale) end
    if original.width and original.height and tracking.SetSize then
        SafeCall(tracking.SetSize, tracking, original.width, original.height)
    end
    if tracking.SetAlpha then SafeCall(tracking.SetAlpha, tracking, original.alpha or 1) end
    self:RestoreNativeTrackingOuterBorder()
end

function QMT:ApplyTrackingButtonPosition()
    local tracking = self:GetNativeTrackingFrame()
    local useCorner = self:ShouldUseNativeTrackingCorner()
    if not tracking then return end

    if not useCorner then
        self:RestoreNativeTrackingFrame()
        return
    end

    self:CaptureNativeTrackingFrame()
    SafeCall(tracking.SetParent, tracking, Minimap)
    SafeCall(tracking.ClearAllPoints, tracking)
    -- Keep the native tracking button as the clickable Blizzard control, but present it
    -- as a clean borderless magnifying glass on the square minimap's upper-right corner.
    SafeCall(tracking.SetPoint, tracking, "TOPRIGHT", Minimap, "TOPRIGHT", 4, 4)
    if tracking.SetFrameStrata then SafeCall(tracking.SetFrameStrata, tracking, "HIGH") end
    if tracking.SetFrameLevel and Minimap.GetFrameLevel then
        SafeCall(tracking.SetFrameLevel, tracking, (Minimap:GetFrameLevel() or 0) + 39)
    end
    if tracking.SetAlpha then SafeCall(tracking.SetAlpha, tracking, 1) end
    if tracking.Show then SafeCall(tracking.Show, tracking) end
    self:HideNativeTrackingOuterBorder()

    if tracking.HookScript and not tracking.QFXMinimapToolsTrackingCornerHooked then
        tracking:HookScript("OnShow", function()
            if QMT:ShouldUseNativeTrackingCorner() then
                SafeCall(QMT.ApplyTrackingButtonPosition, QMT)
                if QMT.statFrames and QMT.statFrames.time then
                    QMT:PlaceStatFrame("time")
                end
            end
        end)
        tracking.QFXMinimapToolsTrackingCornerHooked = true
    end
end

function QMT:ApplyManualMinimapPosition()
    if self.flightModeActive then return end
    if not Minimap or not MinimapCluster or not UIParent then return end
    local db = self.db and self.db.minimap
    if not db or db.autoSnap then return end

    MinimapCluster:SetClampedToScreen(false)
    SafeCall(Minimap.SetClampedToScreen, Minimap, false)
    MinimapCluster:ClearAllPoints()
    MinimapCluster:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", 0, 0)

    local mp = db.manualPoint
    if type(mp) ~= "table" or type(mp.x) ~= "number" or type(mp.y) ~= "number" then
        local cx, cy = Minimap:GetCenter()
        if cx and cy then
            mp = {x = cx, y = cy}
            db.manualPoint = mp
        else
            return
        end
    end

    Minimap:ClearAllPoints()
    Minimap:SetPoint("CENTER", UIParent, "BOTTOMLEFT", mp.x, mp.y)
    self:UpdateSquareBorderPosition()
    self:ApplyQueueStatusButtonPosition()
    self:ApplyMailFramePosition()
    self:ApplyTrackingButtonPosition()
    if self.ApplyNativeControlSkin then self:ApplyNativeControlSkin() end
    self:PlaceBagButton()
    if self.statFrames then
        for key in pairs(self.statFrames) do self:PlaceStatFrame(key) end
        self:UpdateAllStats()
    end
    if self.bagFrame and self.bagFrame:IsShown() then self:LayoutBag() end
end

function QMT:SaveManualMinimapPosition()
    if not Minimap or not self.db or not self.db.minimap then return end
    local cx, cy = Minimap:GetCenter()
    if not cx or not cy then return end
    self.db.minimap.manualPoint = {x = cx, y = cy}
    self.db.minimap.autoSnap = false
end

function QMT:StartMoveMinimap()
    if self.flightModeActive then return end
    if not Minimap or not UIParent or not self.db or self.db.minimap.locked then return end
    local scale = UIParent:GetEffectiveScale() or 1
    local cursorX, cursorY = GetCursorPosition()
    cursorX, cursorY = cursorX / scale, cursorY / scale
    local mapX, mapY = Minimap:GetCenter()
    self.minimapDragOffsetX = (mapX or cursorX) - cursorX
    self.minimapDragOffsetY = (mapY or cursorY) - cursorY
    self.db.minimap.autoSnap = false
    self.squareBorder:SetScript("OnUpdate", function()
        local s = UIParent:GetEffectiveScale() or 1
        local x, y = GetCursorPosition()
        x, y = x / s, y / s
        Minimap:ClearAllPoints()
        Minimap:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x + (QMT.minimapDragOffsetX or 0), y + (QMT.minimapDragOffsetY or 0))
        QMT:UpdateSquareBorderPosition()
        QMT:ApplyQueueStatusButtonPosition()
        QMT:ApplyMailFramePosition()
        QMT:PlaceBagButton()
        if QMT.statFrames then for key in pairs(QMT.statFrames) do QMT:PlaceStatFrame(key) end end
        if QMT.bagFrame and QMT.bagFrame:IsShown() then QMT:LayoutBag() end
    end)
end

function QMT:StopMoveMinimap()
    if self.squareBorder then self.squareBorder:SetScript("OnUpdate", nil) end
    self:SaveManualMinimapPosition()
    self:ApplyManualMinimapPosition()
end

function QMT:ApplyMinimapMoveMode()
    if not self.squareBorder or not self.db or not self.db.minimap then return end
    local unlocked = not self.db.minimap.locked
    self.squareBorder:EnableMouse(unlocked)
    self.squareBorder:SetMovable(unlocked)
    if unlocked then
        self.squareBorder:RegisterForDrag("LeftButton")
        self.squareBorder:SetScript("OnDragStart", function() QMT:StartMoveMinimap() end)
        self.squareBorder:SetScript("OnDragStop", function() QMT:StopMoveMinimap() end)
        self.squareBorder:SetScript("OnMouseUp", function(_, button) if button == "LeftButton" then QMT:StopMoveMinimap() end end)
        self.squareBorder:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
            GameTooltip:AddLine(L.UNLOCK_MOVE_TIP)
            GameTooltip:Show()
        end)
        self.squareBorder:SetScript("OnLeave", function() GameTooltip:Hide() end)
    else
        self.squareBorder:RegisterForDrag()
        self.squareBorder:SetScript("OnDragStart", nil)
        self.squareBorder:SetScript("OnDragStop", nil)
        self.squareBorder:SetScript("OnMouseUp", nil)
        self.squareBorder:SetScript("OnEnter", nil)
        self.squareBorder:SetScript("OnLeave", nil)
    end
end

function QMT:ApplySmartTopRightSnap()
    if self.flightModeActive then return end
    if not self.db or not self.db.minimap or not self.db.minimap.autoSnap then return end
    if not Minimap or not MinimapCluster or not UIParent then return end
    local anchor = self:CreateSnapAnchor()
    local inset = self:GetSnapInset()
    -- Auto snap is fixed behavior. Always use the safe inset instead of reusing old
    -- saved offsets that may push the border off-screen.
    local x = -inset
    local y = -inset
    self.db.minimap.snapX = x
    self.db.minimap.snapY = y
    anchor:ClearAllPoints()
    anchor:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", x, y)

    -- The cluster frame contains large hidden header space in modern clients. Anchor the real
    -- Minimap frame itself to UIParent, but leave a border-width inset so the custom border remains visible.
    MinimapCluster:SetClampedToScreen(false)
    SafeCall(Minimap.SetClampedToScreen, Minimap, false)
    MinimapCluster:ClearAllPoints()
    MinimapCluster:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", 0, 0)
    Minimap:ClearAllPoints()
    Minimap:SetPoint("TOPRIGHT", anchor, "TOPRIGHT", 0, 0)

    self:UpdateSquareBorderPosition()
    self:RequestAttachedElementRefresh(true, true)
end

function QMT:RequestSmartTopRightSnap()
    if self.snapQueued then return end
    self.snapQueued = true
    local function Flush()
        QMT.snapQueued = false
        QMT:ApplySmartTopRightSnap()
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(0, Flush)
    else
        Flush()
    end
end

local defaultSquareBorderEdge = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark"

QMT.borderPresets = QMT.borderPresets or {}
QMT.borderPresetOrder = QMT.borderPresetOrder or {"AUTO_SKIN", "ACTIONBAR", "ELVUI", "NDUI", "DARKMODE", "BLACK", "SILVER", "DARK", "GOLD", "CLASS"}

local function RegisterBuiltInBorderPresets()
    QMT.borderPresets.AUTO_SKIN = {
        label = L.BORDER_AUTO or "Auto skin",
        edgeFile = defaultSquareBorderEdge,
        color = {0.18, 0.18, 0.18, 1},
    }
    QMT.borderPresets.ACTIONBAR = {
        label = L.BORDER_ACTIONBAR or "Action button",
        edgeFile = defaultSquareBorderEdge,
        color = {0.18, 0.18, 0.18, 1},
    }
    QMT.borderPresets.ELVUI = { label = L.BORDER_ELVUI or "ElvUI", edgeFile = defaultSquareBorderEdge, color = {0.10, 0.10, 0.10, 1} }
    QMT.borderPresets.NDUI = { label = L.BORDER_NDUI or "NDui", edgeFile = defaultSquareBorderEdge, color = {0.06, 0.06, 0.06, 1} }
    QMT.borderPresets.DARKMODE = { label = L.BORDER_DARKMODE or "DarkMode", edgeFile = defaultSquareBorderEdge, color = {0.02, 0.02, 0.02, 1} }
    QMT.borderPresets.BLACK = {
        label = L.BORDER_BLACK,
        edgeFile = defaultSquareBorderEdge,
        color = {0, 0, 0, 1},
    }
    QMT.borderPresets.SILVER = {
        label = L.BORDER_SILVER,
        edgeFile = defaultSquareBorderEdge,
        -- Slightly warm silver, close to the default action-button rim.
        color = {0.78, 0.78, 0.72, 1},
    }
    QMT.borderPresets.DARK = {
        label = L.BORDER_DARK,
        edgeFile = defaultSquareBorderEdge,
        color = {0.18, 0.18, 0.18, 1},
    }
    QMT.borderPresets.GOLD = {
        label = L.BORDER_GOLD,
        edgeFile = defaultSquareBorderEdge,
        color = {0.95, 0.72, 0.28, 1},
    }
    QMT.borderPresets.CLASS = {
        label = L.BORDER_CLASS,
        edgeFile = defaultSquareBorderEdge,
        classColor = true,
        color = {0.5019608, 0.5019608, 1.00, 1},
    }
end
RegisterBuiltInBorderPresets()

function QMT:RefreshLocale()
    local choice = self.db and self.db.ui and self.db.ui.language or "AUTO"
    SelectLocale(NormalizeLanguageChoice(choice))
    RegisterBuiltInBorderPresets()
end

function QMT:GetLanguageLabel(key)
    key = NormalizeLanguageChoice(key)
    if key == "zhCN" then return L.LANGUAGE_ZH end
    if key == "enUS" then return L.LANGUAGE_EN end
    return L.LANGUAGE_AUTO
end

function QMT:RefreshSettingsPanelText()
    local panel = self.settingsPanel
    if not panel then return end
    panel.name = L.TITLE
    if panel.qfxTitle then panel.qfxTitle:SetText(L.TITLE) end
    if panel.qfxDesc then panel.qfxDesc:SetText(L.PANEL_DESC) end
    if panel.qfxOpenButton then panel.qfxOpenButton:SetText(L.OPEN_OPTIONS) end
    if panel.qfxResetPosButton then panel.qfxResetPosButton:SetText(L.RESET_MINIMAP_POSITION) end
    if panel.qfxCommandHint then panel.qfxCommandHint:SetText(L.COMMAND_HINT) end
end

function QMT:RefreshButtonManagerText()
    local f = self.buttonManager
    if not f then return end
    if f.qfxTitle then f.qfxTitle:SetText(L.BUTTON_MANAGER) end
    if f.qfxTip then f.qfxTip:SetText(L.BUTTON_MANAGER_TIP) end
    if f.prev then f.prev:SetText(L.PREV) end
    if f.next then f.next:SetText(L.NEXT) end
    if f.rescan then f.rescan:SetText(L.RESCAN) end
end

function QMT:SetUILanguage(key)
    if not self.db then return end
    key = NormalizeLanguageChoice(key)
    self.db.ui = self.db.ui or {}
    self.db.ui.language = key
    self:RefreshLocale()
    self:RefreshSettingsPanelText()
    self:RefreshButtonManagerText()
    if self.buttonManager and self.buttonManager:IsShown() then self:RefreshButtonManager() end
    if self.optionsFrame then
        local wasShown = self.optionsFrame:IsShown()
        self.optionsFrame:Hide()
        self.optionsFrame = nil
        if wasShown then
            if C_Timer and C_Timer.After then
                C_Timer.After(0, function() QMT:ShowOptions() end)
            else
                self:ShowOptions()
            end
        end
    end
    Print(L.LANGUAGE_CHANGED)
end

local function GetClassBorderColor()
    local classFile = select(2, UnitClass("player"))
    local c = classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]
    if c then return c.r or 1, c.g or 1, c.b or 1, c.a or 1 end
    local a = QMT.db and QMT.db.display and QMT.db.display.accent or {0.5019608, 0.5019608, 1.0}
    return a[1] or 0.5019608, a[2] or 0.5019608, a[3] or 1.0, 1
end
local function IsAddonLoadedSafe(name)
    if not name or name == "" then return false end
    if C_AddOns and C_AddOns.IsAddOnLoaded then
        local ok, loaded = pcall(C_AddOns.IsAddOnLoaded, name)
        return ok and loaded and true or false
    end
    if IsAddOnLoaded then
        local ok, loaded = pcall(IsAddOnLoaded, name)
        return ok and loaded and true or false
    end
    return false
end

local function GetElvUI()
    if not _G.ElvUI then return nil end
    local ok, E = pcall(function() return unpack(_G.ElvUI) end)
    return ok and E or nil
end

local function GetQFXExternalBorderColor(mode)
    mode = mode or "AUTO_SKIN"
    local function elv()
        local E = GetElvUI()
        local c = E and E.media and (E.media.bordercolor or E.media.rgbvaluecolor)
        if type(c) == "table" then return c.r or c[1] or 0.10, c.g or c[2] or 0.10, c.b or c[3] or 0.10, c.a or c[4] or 1 end
    end
    local function ndui()
        local nd = type(_G.NDui) == "table" and _G.NDui or type(_G.NDuiDB) == "table" and _G.NDuiDB or type(_G.NDuiConfig) == "table" and _G.NDuiConfig or nil
        local candidates = { nd and nd.media and nd.media.border_color, nd and nd.Media and nd.Media.border_color, nd and nd.db and nd.db.media and nd.db.media.border_color, _G.C and _G.C.media and _G.C.media.border_color, _G.NDuiDB and _G.NDuiDB.media and _G.NDuiDB.media.border_color }
        for _, c in ipairs(candidates) do
            if type(c) == "table" then return c.r or c[1] or 0.08, c.g or c[2] or 0.08, c.b or c[3] or 0.08, c.a or c[4] or 1 end
        end
    end
    if mode == "ELVUI" or mode == "AUTO_SKIN" then
        if GetElvUI() or IsAddonLoadedSafe("ElvUI") then local r,g,b,a = elv(); return r or 0.10, g or 0.10, b or 0.10, a or 1, "ELVUI" end
    end
    if mode == "NDUI" or mode == "AUTO_SKIN" then
        if type(_G.NDui) == "table" or type(_G.NDuiDB) == "table" or IsAddonLoadedSafe("NDui") then local r,g,b,a = ndui(); return r or 0.06, g or 0.06, b or 0.06, a or 1, "NDUI" end
    end
    if mode == "DARKMODE" or mode == "AUTO_SKIN" then
        if type(_G.DarkMode) == "table" or IsAddonLoadedSafe("DarkMode") then return 0.02, 0.02, 0.02, 1, "DARKMODE" end
    end
    return nil
end

local function RegisterQFXSkinTarget(frame, group)
    if not frame then return end
    frame.qfxSkinTarget = true
    frame.qfxSkinGroup = group or "MinimapTools"
    frame.d4border = true
    _G.QFXMinimapTools_SkinTargets = _G.QFXMinimapTools_SkinTargets or {}
    _G.QFXMinimapTools_SkinTargets[frame:GetName() or tostring(frame)] = frame
end

local ROUND_MINIMAP_BUTTON_BORDER = "Interface\\Minimap\\MiniMap-TrackingBorder"
local ROUND_MINIMAP_BUTTON_HIGHLIGHT = "Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight"



local function TexturePath(texture)
    if not texture or not texture.GetTexture then return nil end
    local ok, tex = pcall(texture.GetTexture, texture)
    if not ok then return nil end
    if type(tex) == "string" then return tex:lower() end
    return nil
end

local function LooksLikeNativeRoundButtonBorder(texture)
    local path = TexturePath(texture)
    if not path then return false end
    if path:find("qfxminimaptools", 1, true) then return false end
    if path:find("quickslot", 1, true) or path:find("buttonhilight%-square") then return false end
    if path:find("trackingborder", 1, true) then return true end
    if path:find("minimap", 1, true) and path:find("border", 1, true) then return true end
    if path:find("queue", 1, true) and path:find("border", 1, true) then return true end
    return false
end

local function FrameHasNativeRoundBorder(frame)
    if not frame then return false end
    local function CheckRegions(obj)
        if not obj or not obj.GetRegions then return false end
        for _, region in ipairs({obj:GetRegions()}) do
            if region and region.IsShown and region:IsShown() and LooksLikeNativeRoundButtonBorder(region) then
                local a = region.GetAlpha and region:GetAlpha() or 1
                if a and a > 0 then return true end
            end
        end
        return false
    end
    if CheckRegions(frame) then return true end
    if frame.GetChildren then
        for _, child in ipairs({frame:GetChildren()}) do
            if CheckRegions(child) then return true end
        end
    end
    return false
end

local function ApplyRoundMinimapButtonBorder(frame, color, show, preferNative)
    if not frame then return end
    if show == false then
        if frame.QFXRoundMinimapBorder then frame.QFXRoundMinimapBorder:Hide() end
        if frame.QFXRoundMinimapHighlight then frame.QFXRoundMinimapHighlight:Hide() end
        return
    end

    -- QueueStatusButton already owns a proper Blizzard round border on clients that
    -- expose it. In that case do not add any QFX border; just leave the native art alone.
    if preferNative and FrameHasNativeRoundBorder(frame) then
        if frame.QFXRoundMinimapBorder then frame.QFXRoundMinimapBorder:Hide() end
        if frame.QFXRoundMinimapHighlight then frame.QFXRoundMinimapHighlight:Hide() end
        return
    end

    local r, g, b, a = 0.18, 0.18, 0.18, 1
    if type(color) == "table" then r, g, b, a = color[1] or color.r or r, color[2] or color.g or g, color[3] or color.b or b, color[4] or color.a or a end

    if not frame.QFXRoundMinimapBorder then
        if InCombatLockdown and InCombatLockdown() and frame.IsProtected and frame:IsProtected() then return end
        frame.QFXRoundMinimapBorder = frame:CreateTexture(nil, "OVERLAY")
        frame.QFXRoundMinimapBorder:SetTexture(ROUND_MINIMAP_BUTTON_BORDER)
    end
    local w = frame.GetWidth and frame:GetWidth() or 24
    local h = frame.GetHeight and frame:GetHeight() or 24
    local size = math.max(42, (math.max(w or 24, h or 24) or 24) + 20)
    frame.QFXRoundMinimapBorder:ClearAllPoints()
    frame.QFXRoundMinimapBorder:SetPoint("CENTER", frame, "CENTER", -1, 0)
    frame.QFXRoundMinimapBorder:SetSize(size, size)
    frame.QFXRoundMinimapBorder:SetVertexColor(r, g, b, a)
    frame.QFXRoundMinimapBorder:Show()

    if not frame.QFXRoundMinimapHighlight then
        if InCombatLockdown and InCombatLockdown() and frame.IsProtected and frame:IsProtected() then return end
        frame.QFXRoundMinimapHighlight = frame:CreateTexture(nil, "HIGHLIGHT")
        frame.QFXRoundMinimapHighlight:SetTexture(ROUND_MINIMAP_BUTTON_HIGHLIGHT)
        frame.QFXRoundMinimapHighlight:SetBlendMode("ADD")
    end
    frame.QFXRoundMinimapHighlight:ClearAllPoints()
    frame.QFXRoundMinimapHighlight:SetPoint("CENTER", frame, "CENTER", 0, 0)
    frame.QFXRoundMinimapHighlight:SetSize(math.max(28, size - 14), math.max(28, size - 14))
end

function QMT:ApplyNativeControlSkin()
    -- Do not force action-button square borders onto native minimap controls.
    -- Queue eye: prefer Blizzard's own round frame. Difficulty badge: use the same
    -- LibDBIcon-style round minimap frame as a fallback because QFX draws the text itself.
    local db = self.db and self.db.minimap
    local show = db and db.enabled and db.square
    local style = self.GetBorderStyle and self:GetBorderStyle() or {r = 0.18, g = 0.18, b = 0.18, a = 1}
    local color = {style.r or 0.18, style.g or 0.18, style.b or 0.18, style.a or 1}

    local q = self:GetManagedNativeQueueFrame()
    if q then
        local qShown = show and (not q.IsShown or q:IsShown())
        ApplyRoundMinimapButtonBorder(q, color, qShown, true)
    end

    local diff = self.statFrames and self.statFrames.difficulty
    if diff then
        -- Difficulty is addon-owned text, not a minimap button. Keep it unframed so
        -- it does not look like an escaped collected icon.
        ApplyRoundMinimapButtonBorder(diff, color, false, false)
    end
end

local function NormaliseBorderStyle(style)
    if type(style) ~= "table" then return nil end
    local edgeFile = style.edgeFile or defaultSquareBorderEdge
    local edgeSize = tonumber(style.edgeSize or style.borderSize or (QMT.db and QMT.db.minimap and QMT.db.minimap.borderSize) or 3) or 3
    local r, g, b, a
    if type(style.color) == "table" then
        r, g, b, a = style.color[1], style.color[2], style.color[3], style.color[4]
    else
        r, g, b, a = style.r, style.g, style.b, style.a
    end
    r = Clamp(tonumber(r) or 0, 0, 1)
    g = Clamp(tonumber(g) or 0, 0, 1)
    b = Clamp(tonumber(b) or 0, 0, 1)
    a = Clamp(tonumber(a) or 1, 0, 1)
    return { edgeFile = edgeFile, edgeSize = edgeSize, r = r, g = g, b = b, a = a }
end

function QMT:RegisterBorderPreset(key, label, r, g, b, a, edgeFile, edgeSize)
    if type(key) ~= "string" or key == "" then return false end
    key = key:upper()
    self.borderPresets[key] = {
        label = label or key,
        edgeFile = edgeFile or defaultSquareBorderEdge,
        edgeSize = edgeSize,
        color = {Clamp(tonumber(r) or 1, 0, 1), Clamp(tonumber(g) or 1, 0, 1), Clamp(tonumber(b) or 1, 0, 1), Clamp(tonumber(a) or 1, 0, 1)},
    }
    local exists = false
    for _, v in ipairs(self.borderPresetOrder) do if v == key then exists = true break end end
    if not exists then table.insert(self.borderPresetOrder, key) end
    return true
end

function QMT:SetBorderPreset(key, noSave)
    if type(key) ~= "string" then return false end
    key = key:upper()
    if not self.borderPresets[key] then return false end
    if noSave then
        local preset = self.borderPresets[key]
        local r, g, b, a
        if preset.classColor then r, g, b, a = GetClassBorderColor() else r, g, b, a = unpack(preset.color or {0, 0, 0, 1}) end
        self.runtimeBorderStyle = { edgeFile = preset.edgeFile or defaultSquareBorderEdge, edgeSize = preset.edgeSize, r = r, g = g, b = b, a = a }
    elseif self.db and self.db.minimap then
        self.runtimeBorderStyle = nil
        self.db.minimap.borderPreset = key
        self.db.minimap.borderEdgeFile = nil
        if key ~= "CLASS" then
            local preset = self.borderPresets[key]
            self.db.minimap.borderColor = {unpack(preset.color or {0, 0, 0, 1})}
        end
    end
    self:ApplySquareBorderStyle()
    self:RefreshBorderPresetControls()
    return true
end

function QMT:SetBorderColor(r, g, b, a, noSave, edgeFile, edgeSize)
    local style = NormaliseBorderStyle({r = r, g = g, b = b, a = a, edgeFile = edgeFile, edgeSize = edgeSize})
    if not style then return false end
    if noSave then
        self.runtimeBorderStyle = style
    elseif self.db and self.db.minimap then
        self.runtimeBorderStyle = nil
        self.db.minimap.borderPreset = "CUSTOM"
        self.db.minimap.borderColor = {style.r, style.g, style.b, style.a}
        self.db.minimap.borderEdgeFile = style.edgeFile
        if edgeSize then self.db.minimap.borderSize = style.edgeSize end
    end
    self:ApplySquareBorderStyle()
    self:RefreshBorderPresetControls()
    return true
end

function QMT:SetBorderStyle(style, noSave)
    if type(style) == "string" then return self:SetBorderPreset(style, noSave) end
    if type(style) ~= "table" then return false end
    if style.preset then return self:SetBorderPreset(style.preset, noSave) end
    local color = style.color or style
    return self:SetBorderColor(color.r or color[1], color.g or color[2], color.b or color[3], color.a or color[4], noSave, style.edgeFile, style.edgeSize or style.borderSize)
end

function QMT:GetBorderStyle()
    if self.runtimeBorderStyle then
        local s = self.runtimeBorderStyle
        return { preset = "RUNTIME", edgeFile = s.edgeFile, edgeSize = s.edgeSize, r = s.r, g = s.g, b = s.b, a = s.a }
    end

    local db = self.db and self.db.minimap or {}
    local key = db.borderPreset or "DARK"
    local preset = self.borderPresets[key]
    local edgeFile = db.borderEdgeFile or (preset and preset.edgeFile) or defaultSquareBorderEdge
    local edgeSize = tonumber(db.borderSize) or 3
    local r, g, b, a

    local er, eg, eb, ea = nil
    if key == "AUTO_SKIN" or key == "ELVUI" or key == "NDUI" or key == "DARKMODE" then
        er, eg, eb, ea = GetQFXExternalBorderColor(key)
    end
    if er then
        r, g, b, a = er, eg, eb, ea
    elseif preset and preset.classColor then
        r, g, b, a = GetClassBorderColor()
    elseif preset and preset.color then
        r, g, b, a = unpack(preset.color)
    elseif type(db.borderColor) == "table" then
        r, g, b, a = db.borderColor[1], db.borderColor[2], db.borderColor[3], db.borderColor[4]
    else
        r, g, b, a = 0, 0, 0, 1
    end

    r = Clamp(tonumber(r) or 0, 0, 1)
    g = Clamp(tonumber(g) or 0, 0, 1)
    b = Clamp(tonumber(b) or 0, 0, 1)
    a = Clamp(tonumber(a) or 1, 0, 1)
    return { preset = key, edgeFile = edgeFile, edgeSize = edgeSize, r = r, g = g, b = b, a = a }
end

QMT.GetMinimapBorderStyle = QMT.GetBorderStyle
QMT.SetMinimapBorderStyle = QMT.SetBorderStyle

function QMT:EnsureSquareBorderLines()
    if not self.squareBorder then return end
    if self.squareBorderLines then return end
    self.squareBorderLines = {
        top = self.squareBorder:CreateTexture(nil, "BORDER"),
        bottom = self.squareBorder:CreateTexture(nil, "BORDER"),
        left = self.squareBorder:CreateTexture(nil, "BORDER"),
        right = self.squareBorder:CreateTexture(nil, "BORDER"),
    }
end

function QMT:ApplySquareBorderStyle()
    if not self.squareBorder or not self.db or not self.db.minimap then return end
    local style = self:GetBorderStyle()
    local edgeSize = Clamp(tonumber(style.edgeSize or self.db.minimap.borderSize) or 3, 1, 12)
    local signature = table.concat({
        tostring(style.preset or ""),
        tostring(style.edgeFile or ""),
        tostring(edgeSize),
        string.format("%.4f", style.r or 0),
        string.format("%.4f", style.g or 0),
        string.format("%.4f", style.b or 0),
        string.format("%.4f", style.a or 1),
    }, "|")
    if self.squareBorderStyleSignature == signature and self.squareBorderLines then return end
    self.squareBorderStyleSignature = signature

    -- Do not rely on Backdrop edge tinting for the visible border. Some edge
    -- textures are dark/pre-colored, so SetBackdropBorderColor can appear to do
    -- nothing. Solid line textures are always tintable and refresh immediately.
    if self.squareBorder.SetBackdrop then self.squareBorder:SetBackdrop(nil) end
    self:EnsureSquareBorderLines()
    local lines = self.squareBorderLines
    if not lines then return end

    lines.top:ClearAllPoints()
    lines.top:SetPoint("TOPLEFT", self.squareBorder, "TOPLEFT", 0, 0)
    lines.top:SetPoint("TOPRIGHT", self.squareBorder, "TOPRIGHT", 0, 0)
    lines.top:SetHeight(edgeSize)

    lines.bottom:ClearAllPoints()
    lines.bottom:SetPoint("BOTTOMLEFT", self.squareBorder, "BOTTOMLEFT", 0, 0)
    lines.bottom:SetPoint("BOTTOMRIGHT", self.squareBorder, "BOTTOMRIGHT", 0, 0)
    lines.bottom:SetHeight(edgeSize)

    lines.left:ClearAllPoints()
    lines.left:SetPoint("TOPLEFT", self.squareBorder, "TOPLEFT", 0, -edgeSize)
    lines.left:SetPoint("BOTTOMLEFT", self.squareBorder, "BOTTOMLEFT", 0, edgeSize)
    lines.left:SetWidth(edgeSize)

    lines.right:ClearAllPoints()
    lines.right:SetPoint("TOPRIGHT", self.squareBorder, "TOPRIGHT", 0, -edgeSize)
    lines.right:SetPoint("BOTTOMRIGHT", self.squareBorder, "BOTTOMRIGHT", 0, edgeSize)
    lines.right:SetWidth(edgeSize)

    for _, tex in pairs(lines) do
        tex:SetColorTexture(style.r or 0, style.g or 0, style.b or 0, style.a or 1)
        tex:Show()
        if (style.preset == "DARKMODE" or style.preset == "AUTO_SKIN") and _G.DarkMode and type(_G.DarkMode.UpdateColor) == "function" then
            pcall(_G.DarkMode.UpdateColor, _G.DarkMode, tex, "ui")
        end
    end
    RegisterQFXSkinTarget(self.squareBorder, "MinimapBorder")
    if self.ApplyNativeControlSkin then self:ApplyNativeControlSkin() end
end

function QMT:GetBorderPresetLabel(key)
    key = key or (self.db and self.db.minimap and self.db.minimap.borderPreset) or "DARK"
    local preset = self.borderPresets and self.borderPresets[key]
    if preset and preset.label then return preset.label end
    if key == "CUSTOM" or key == "RUNTIME" then return L.BORDER_CUSTOM end
    return tostring(key or "")
end

function QMT:RefreshBorderPresetControls()
    local f = self.optionsFrame
    if not f then return end
    local key = self.db and self.db.minimap and self.db.minimap.borderPreset or "DARK"
    if self.runtimeBorderStyle then key = "RUNTIME" end
    if f.borderPresetDropdown then
        f.borderPresetDropdown:SetText(self:GetBorderPresetLabel(key))
    end
end


-- ############################################################
function QMT:ApplyMinimapSettings()
    local db = self.db.minimap
    if not Minimap or not MinimapCluster then return end

    if not self.originalGetMinimapShape then
        self.originalGetMinimapShape = _G.GetMinimapShape
    end

    -- 自动贴近屏幕边缘：作为默认行为固定开启，不再放到设置界面里。
    db.unclamp = true

    if db.enabled then
        local scale = Clamp(db.scale, 0.50, 2.00)
        db.scale = scale
        -- Direct top-right anchoring works best when the real Minimap frame is scaled.
        -- Scaling only MinimapCluster can appear capped around 1.0 on some UI layouts.
        MinimapCluster:SetScale(1)
        if Minimap.SetScale then Minimap:SetScale(scale) end
        MinimapCluster:SetClampedToScreen(false)
        SafeCall(Minimap.SetClampedToScreen, Minimap, false)

        if db.square then
            _G.GetMinimapShape = function() return "SQUARE" end
            SafeCall(Minimap.SetMaskTexture, Minimap, "Interface\\Buttons\\WHITE8X8")
            self:SetRoundMinimapArtHidden(true)
            self:SetNativeMinimapControlsHidden(true)
        else
            _G.GetMinimapShape = self.originalGetMinimapShape or function() return "ROUND" end
            SafeCall(Minimap.SetMaskTexture, Minimap, "Interface\\CHARACTERFRAME\\TempPortraitAlphaMask")
            self:SetRoundMinimapArtHidden(false)
            self:SetNativeMinimapControlsHidden(false)
        end
    else
        MinimapCluster:SetScale(1)
        if Minimap.SetScale then Minimap:SetScale(1) end
        MinimapCluster:SetClampedToScreen(false)
        SafeCall(Minimap.SetClampedToScreen, Minimap, false)
        _G.GetMinimapShape = self.originalGetMinimapShape or _G.GetMinimapShape
        SafeCall(Minimap.SetMaskTexture, Minimap, "Interface\\CHARACTERFRAME\\TempPortraitAlphaMask")
        self:SetRoundMinimapArtHidden(false)
        self:SetNativeMinimapControlsHidden(false)
    end

    if not self.squareBorder then
        self.squareBorder = CreateFrame("Frame", "QFXMinimapToolsSquareBorder", Minimap, BackdropTemplateMixin and "BackdropTemplate")
        self.squareBorder:SetFrameStrata("LOW")
        if self.squareBorder.SetFrameLevel and Minimap.GetFrameLevel then
            self.squareBorder:SetFrameLevel(math.max(0, (Minimap:GetFrameLevel() or 1) - 1))
        end
        self.squareBorder:SetPoint("TOPLEFT", Minimap, "TOPLEFT", -3, 3)
        self.squareBorder:SetPoint("BOTTOMRIGHT", Minimap, "BOTTOMRIGHT", 3, -3)
        self.squareBorder:SetBackdrop({
            edgeFile = defaultSquareBorderEdge,
            edgeSize = db.borderSize or 3,
        })
        self.squareBorder:SetBackdropBorderColor(0, 0, 0, 1)
    end
    self:ApplySquareBorderStyle()
    self.squareBorder:SetShown(db.enabled and db.square)
    self:ApplyMinimapMoveMode()
    self:ApplyQueueStatusButtonPosition()
    self:ApplyMailFramePosition()
    self:ApplyTrackingButtonPosition()
    if self.ApplyNativeControlSkin then self:ApplyNativeControlSkin() end
    if db.autoSnap then self:ApplySmartTopRightSnap() else self:ApplyManualMinimapPosition() end

    if AddonCompartmentFrame then
        if not self.compartmentHooked then
            AddonCompartmentFrame:HookScript("OnShow", function(frame)
                if QMT.db and QMT.db.minimap and (QMT.db.minimap.hideCompartment or QMT:ShouldCleanSquareMinimap()) then frame:Hide() end
            end)
            self.compartmentHooked = true
        end
        if db.hideCompartment or self:ShouldCleanSquareMinimap() then AddonCompartmentFrame:Hide() else AddonCompartmentFrame:Show() end
    end

    self:RefreshOutdoorFlightWatcher()
    self:UpdateOutdoorFlightCenterState(true)
end

-- ############################################################
-- Text displays
-- ############################################################
